from django.shortcuts import render
from django.contrib import admin
from django.http import HttpResponse
from django.shortcuts import render, redirect

# Create your views here.
from .models import *
from .forms import BookForm


def home(request):
    return render(request, "home.html", context={"current_tab": "home"})


def readers(request):
    return render(request, "readers.html", context={"current_tab": "readers"})


def shopping(request):
    return HttpResponse("Welcome to Shopping")


def save_student(request):
    student_name = request.POST['student_name']
    return render(request, "welcome.html", context={'student_name': student_name})


def readers_tab(request):
    readers = reader.objects.all()
    print(f"Readers: {readers}")  # Debugging line
    return render(request, "readers.html", context={
        "current_tab": "readers",
        "readers": readers
    })

def save_reader(request):
    reader_item = reader(reference_id=request.POST['reference_id'],
                         reader_name=request.POST['reader_name'],
                         reader_contact=request.POST['reader_contact'],
                         reader_address=request.POST['address'],
                         active=True
                         )
    reader_item.save()
    return redirect('/readers')


def add_book(request):
    if request.method == "POST":
        form = BookForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('book_list')  # Redirect to a list of books or another appropriate view
    else:
        form = BookForm()

    return render(request, 'add_book.html', {'form': form})


def book_list(request):
    books = Book.objects.all()
    print(f"Books: {books}")  # Debugging line
    return render(request, "book_list.html", context={
        "current_tab": "books",
        "books": books
    })
